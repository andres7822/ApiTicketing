<?php

    namespace App\Api\Action\Cat_alogoDeDocumento;

    use App\Entity\Cat_alogoDeDocumento;
    use App\Service\Cat_alogoDeDocumento\Cat_alogoDeDocumentoUpdateService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Update{
        private Cat_alogoDeDocumentoUpdateService $service;

        public function __construct(Cat_alogoDeDocumentoUpdateService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id, Request $request): Cat_alogoDeDocumento{
            $Nombre = RequestService::getField($request, 'Nombre');
            $Descripci_on = RequestService::getField($request, 'Descripci_on', false);
            $Activo = RequestService::getField($request, 'Activo');
            $Prioridad = RequestService::getField($request, 'Prioridad');
            $Origen = RequestService::getField($request, 'Origen');
            $Requerido = RequestService::getField($request, 'Requerido', false);

            return $this->service->update($id, $Nombre, $Descripci_on, $Activo, $Prioridad, $Origen, $Requerido);
        }
    }