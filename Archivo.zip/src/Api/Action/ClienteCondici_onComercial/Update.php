<?php

    namespace App\Api\Action\ClienteCondici_onComercial;

    use App\Entity\ClienteCondici_onComercial;
    use App\Service\ClienteCondici_onComercial\ClienteCondici_onComercialUpdateService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Update{
        private ClienteCondici_onComercialUpdateService $service;

        public function __construct(ClienteCondici_onComercialUpdateService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id, Request $request): ClienteCondici_onComercial{
            $Cliente = RequestService::getField($request, 'Cliente');
            $Cat_alogoCondicionesComerciales = RequestService::getField($request, 'Cat_alogoCondicionesComerciales');
            $Descripci_on = RequestService::getField($request, 'Descripci_on');
            $FechaAceptaci_on = RequestService::getField($request, 'FechaAceptaci_on', false);
            $Status = RequestService::getField($request, 'Status');
            $UsuarioRegistr_o = RequestService::getField($request, 'UsuarioRegistr_o');
            $FechaTupla = RequestService::getField($request, 'FechaTupla');

            return $this->service->update($id, $Cliente, $Cat_alogoCondicionesComerciales, $Descripci_on, $FechaAceptaci_on, $Status, $UsuarioRegistr_o, $FechaTupla);
        }
    }