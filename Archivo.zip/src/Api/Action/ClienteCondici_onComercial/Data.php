<?php

    namespace App\Api\Action\ClienteCondici_onComercial;

    use App\Entity\ClienteCondici_onComercial;
    use App\Service\ClienteCondici_onComercial\ClienteCondici_onComercialDataService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Data{
        private ClienteCondici_onComercialDataService $service;

        public function __construct(ClienteCondici_onComercialDataService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): ClienteCondici_onComercial{
            return $this->service->data($id);
        }
    }