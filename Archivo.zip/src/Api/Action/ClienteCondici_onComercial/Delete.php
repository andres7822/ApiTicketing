<?php

    namespace App\Api\Action\ClienteCondici_onComercial;

    use App\Entity\ClienteCondici_onComercial;
    use App\Service\ClienteCondici_onComercial\ClienteCondici_onComercialDeleteService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Delete{
        private ClienteCondici_onComercialDeleteService $service;

        public function __construct(ClienteCondici_onComercialDeleteService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): ClienteCondici_onComercial{
            return $this->service->delete($id);
        }
    }