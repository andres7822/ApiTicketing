<?php

    namespace App\Api\Action\StatusProspectaci_on;

    use App\Entity\StatusProspectaci_on;
    use App\Service\StatusProspectaci_on\StatusProspectaci_onUpdateService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Update{
        private StatusProspectaci_onUpdateService $service;

        public function __construct(StatusProspectaci_onUpdateService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id, Request $request): StatusProspectaci_on{
            $Descipci_on = RequestService::getField($request, 'Descipci_on');
            $Acotaci_on = RequestService::getField($request, 'Acotaci_on');
            $Origen = RequestService::getField($request, 'Origen');
            $Nombre = RequestService::getField($request, 'Nombre', false);
            $Descripci_on = RequestService::getField($request, 'Descripci_on', false);

            return $this->service->update($id, $Descipci_on, $Acotaci_on, $Origen, $Nombre, $Descripci_on);
        }
    }