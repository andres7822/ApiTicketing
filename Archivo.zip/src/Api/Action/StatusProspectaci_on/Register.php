<?php

    namespace App\Api\Action\StatusProspectaci_on;

    use App\Entity\StatusProspectaci_on;
    use App\Service\StatusProspectaci_on\StatusProspectaci_onRegisterService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Register{
        private StatusProspectaci_onRegisterService $service;

        public function __construct(StatusProspectaci_onRegisterService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(Request $request): StatusProspectaci_on{
            $Descipci_on = RequestService::getField($request, 'Descipci_on');
            $Acotaci_on = RequestService::getField($request, 'Acotaci_on');
            $Origen = RequestService::getField($request, 'Origen');
            $Nombre = RequestService::getField($request, 'Nombre', false);
            $Descripci_on = RequestService::getField($request, 'Descripci_on', false);

            return $this->service->create($Descipci_on, $Acotaci_on, $Origen, $Nombre, $Descripci_on);
        }
    }