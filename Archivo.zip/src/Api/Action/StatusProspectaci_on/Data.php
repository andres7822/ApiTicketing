<?php

    namespace App\Api\Action\StatusProspectaci_on;

    use App\Entity\StatusProspectaci_on;
    use App\Service\StatusProspectaci_on\StatusProspectaci_onDataService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Data{
        private StatusProspectaci_onDataService $service;

        public function __construct(StatusProspectaci_onDataService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): StatusProspectaci_on{
            return $this->service->data($id);
        }
    }