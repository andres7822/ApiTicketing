<?php

    namespace App\Api\Action\Prospectaci_on;

    use App\Entity\Prospectaci_on;
    use App\Service\Prospectaci_on\Prospectaci_onRegisterService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Register{
        private Prospectaci_onRegisterService $service;

        public function __construct(Prospectaci_onRegisterService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(Request $request): Prospectaci_on{
            $Cliente = RequestService::getField($request, 'Cliente');
            $FechaYHora = RequestService::getField($request, 'FechaYHora');
            $TipoDeServicio = RequestService::getField($request, 'TipoDeServicio');
            $Descripci_onDelServicio = RequestService::getField($request, 'Descripci_onDelServicio');
            $Usuario = RequestService::getField($request, 'Usuario');
            $Empleado = RequestService::getField($request, 'Empleado');
            $Status = RequestService::getField($request, 'Status');
            $Canalizado = RequestService::getField($request, 'Canalizado');

            return $this->service->create($Cliente, $FechaYHora, $TipoDeServicio, $Descripci_onDelServicio, $Usuario, $Empleado, $Status, $Canalizado);
        }
    }