<?php

    namespace App\Api\Action\Prospectaci_on;

    use App\Entity\Prospectaci_on;
    use App\Service\Prospectaci_on\Prospectaci_onDeleteService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Delete{
        private Prospectaci_onDeleteService $service;

        public function __construct(Prospectaci_onDeleteService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): Prospectaci_on{
            return $this->service->delete($id);
        }
    }