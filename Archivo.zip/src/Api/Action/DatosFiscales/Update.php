<?php

    namespace App\Api\Action\DatosFiscales;

    use App\Entity\DatosFiscales;
    use App\Service\DatosFiscales\DatosFiscalesUpdateService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Update{
        private DatosFiscalesUpdateService $service;

        public function __construct(DatosFiscalesUpdateService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id, Request $request): DatosFiscales{
            $NombreORaz_onSocial = RequestService::getField($request, 'NombreORaz_onSocial');
            $RFC = RequestService::getField($request, 'RFC');
            $R_egimenFiscal = RequestService::getField($request, 'R_egimenFiscal');
            $Domicilio = RequestService::getField($request, 'Domicilio');
            $FechaTupla = RequestService::getField($request, 'FechaTupla');
            $Origen = RequestService::getField($request, 'Origen');
            $Tupla = RequestService::getField($request, 'Tupla');

            return $this->service->update($id, $NombreORaz_onSocial, $RFC, $R_egimenFiscal, $Domicilio, $FechaTupla, $Origen, $Tupla);
        }
    }