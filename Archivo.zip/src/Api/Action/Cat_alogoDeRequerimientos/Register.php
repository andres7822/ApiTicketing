<?php

    namespace App\Api\Action\Cat_alogoDeRequerimientos;

    use App\Entity\Cat_alogoDeRequerimientos;
    use App\Service\Cat_alogoDeRequerimientos\Cat_alogoDeRequerimientosRegisterService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Register{
        private Cat_alogoDeRequerimientosRegisterService $service;

        public function __construct(Cat_alogoDeRequerimientosRegisterService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(Request $request): Cat_alogoDeRequerimientos{
            $TipoDeServicio = RequestService::getField($request, 'TipoDeServicio');
            $Requerimiento = RequestService::getField($request, 'Requerimiento');
            $Orden = RequestService::getField($request, 'Orden');
            $Requerido = RequestService::getField($request, 'Requerido', false);
            $Cat_alogo = RequestService::getField($request, 'Cat_alogo', false);

            return $this->service->create($TipoDeServicio, $Requerimiento, $Orden, $Requerido, $Cat_alogo);
        }
    }