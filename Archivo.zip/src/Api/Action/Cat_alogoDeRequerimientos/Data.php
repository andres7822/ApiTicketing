<?php

    namespace App\Api\Action\Cat_alogoDeRequerimientos;

    use App\Entity\Cat_alogoDeRequerimientos;
    use App\Service\Cat_alogoDeRequerimientos\Cat_alogoDeRequerimientosDataService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Data{
        private Cat_alogoDeRequerimientosDataService $service;

        public function __construct(Cat_alogoDeRequerimientosDataService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): Cat_alogoDeRequerimientos{
            return $this->service->data($id);
        }
    }