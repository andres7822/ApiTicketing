<?php

    namespace App\Api\Action\Cat_alogoDeRequerimientos;

    use App\Entity\Cat_alogoDeRequerimientos;
    use App\Service\Cat_alogoDeRequerimientos\Cat_alogoDeRequerimientosUpdateService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Update{
        private Cat_alogoDeRequerimientosUpdateService $service;

        public function __construct(Cat_alogoDeRequerimientosUpdateService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id, Request $request): Cat_alogoDeRequerimientos{
            $TipoDeServicio = RequestService::getField($request, 'TipoDeServicio');
            $Requerimiento = RequestService::getField($request, 'Requerimiento');
            $Orden = RequestService::getField($request, 'Orden');
            $Requerido = RequestService::getField($request, 'Requerido', false);
            $Cat_alogo = RequestService::getField($request, 'Cat_alogo', false);

            return $this->service->update($id, $TipoDeServicio, $Requerimiento, $Orden, $Requerido, $Cat_alogo);
        }
    }