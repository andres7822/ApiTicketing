<?php

    namespace App\Api\Action\Cat_alogoDeRequerimientos;

    use App\Entity\Cat_alogoDeRequerimientos;
    use App\Service\Cat_alogoDeRequerimientos\Cat_alogoDeRequerimientosDeleteService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Delete{
        private Cat_alogoDeRequerimientosDeleteService $service;

        public function __construct(Cat_alogoDeRequerimientosDeleteService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(int $id): Cat_alogoDeRequerimientos{
            return $this->service->delete($id);
        }
    }