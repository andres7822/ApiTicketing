<?php

    namespace App\Api\Action\ClientePersona;

    use App\Entity\ClientePersona;
    use App\Service\ClientePersona\ClientePersonaRegisterService;
    use App\Service\Request\RequestService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpFoundation\Request;

    class Register{
        private ClientePersonaRegisterService $service;

        public function __construct(ClientePersonaRegisterService $service){
            $this->service = $service;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function __invoke(Request $request): ClientePersona{
            $Cliente = RequestService::getField($request, 'Cliente');
            $Persona = RequestService::getField($request, 'Persona');
            $Relaci_on = RequestService::getField($request, 'Relaci_on');
            $Titulo = RequestService::getField($request, 'Titulo', false);
            $Tel_efono = RequestService::getField($request, 'Tel_efono', false);
            $Tel_efono2 = RequestService::getField($request, 'Tel_efono2', false);
            $CorreoElectr_onico = RequestService::getField($request, 'CorreoElectr_onico', false);

            return $this->service->create($Cliente, $Persona, $Relaci_on, $Titulo, $Tel_efono, $Tel_efono2, $CorreoElectr_onico);
        }
    }