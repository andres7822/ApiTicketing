<?php

    namespace App\Repository;

    use App\Entity\Cat_alogoDeDocumento;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class Cat_alogoDeDocumentoRepository extends BaseRepository{

        protected static function entityClass(): string{
            return Cat_alogoDeDocumento::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(Cat_alogoDeDocumento $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): Cat_alogoDeDocumento{
            if(null == $Cat_alogoDeDocumento = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de Cat_alogoDeDocumento con id $id");
            }

            return $Cat_alogoDeDocumento;
        }
    }