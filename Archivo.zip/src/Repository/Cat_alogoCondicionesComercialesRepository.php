<?php

    namespace App\Repository;

    use App\Entity\Cat_alogoCondicionesComerciales;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class Cat_alogoCondicionesComercialesRepository extends BaseRepository{

        protected static function entityClass(): string{
            return Cat_alogoCondicionesComerciales::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(Cat_alogoCondicionesComerciales $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): Cat_alogoCondicionesComerciales{
            if(null == $Cat_alogoCondicionesComerciales = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de Cat_alogoCondicionesComerciales con id $id");
            }

            return $Cat_alogoCondicionesComerciales;
        }
    }