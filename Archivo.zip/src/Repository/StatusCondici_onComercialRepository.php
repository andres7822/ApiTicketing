<?php

    namespace App\Repository;

    use App\Entity\StatusCondici_onComercial;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class StatusCondici_onComercialRepository extends BaseRepository{

        protected static function entityClass(): string{
            return StatusCondici_onComercial::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(StatusCondici_onComercial $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): StatusCondici_onComercial{
            if(null == $StatusCondici_onComercial = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de StatusCondici_onComercial con id $id");
            }

            return $StatusCondici_onComercial;
        }
    }