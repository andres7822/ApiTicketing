<?php

    namespace App\Repository;

    use App\Entity\Prospectaci_on;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class Prospectaci_onRepository extends BaseRepository{

        protected static function entityClass(): string{
            return Prospectaci_on::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(Prospectaci_on $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): Prospectaci_on{
            if(null == $Prospectaci_on = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de Prospectaci_on con id $id");
            }

            return $Prospectaci_on;
        }
    }