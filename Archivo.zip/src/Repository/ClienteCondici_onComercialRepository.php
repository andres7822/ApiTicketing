<?php

    namespace App\Repository;

    use App\Entity\ClienteCondici_onComercial;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class ClienteCondici_onComercialRepository extends BaseRepository{

        protected static function entityClass(): string{
            return ClienteCondici_onComercial::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(ClienteCondici_onComercial $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): ClienteCondici_onComercial{
            if(null == $ClienteCondici_onComercial = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de ClienteCondici_onComercial con id $id");
            }

            return $ClienteCondici_onComercial;
        }
    }