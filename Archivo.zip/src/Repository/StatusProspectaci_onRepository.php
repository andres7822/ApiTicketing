<?php

    namespace App\Repository;

    use App\Entity\StatusProspectaci_on;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;
    use Symfony\Component\HttpKernel\Exception\ConflictHttpException;

    class StatusProspectaci_onRepository extends BaseRepository{

        protected static function entityClass(): string{
            return StatusProspectaci_on::class;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function save(StatusProspectaci_on $entity): void{
            $this->saveEntity($entity);
        }

        public function findById(int $id): StatusProspectaci_on{
            if(null == $StatusProspectaci_on = $this->objectRepository->find($id)){
                throw new ConflictHttpException("No existe el registro de StatusProspectaci_on con id $id");
            }

            return $StatusProspectaci_on;
        }
    }