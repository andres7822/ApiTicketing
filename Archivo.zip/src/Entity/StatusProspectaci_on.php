<?php

    namespace App\Entity;

    class StatusProspectaci_on{
        private int $id;
        private string $Descipci_on;
        private string $Acotaci_on;
        private string $Origen;
        private ?string $Nombre;
        private ?string $Descripci_on;

        public function __construct(string $Descipci_on, int $Acotaci_on, string $Origen, ?string $Nombre, ?string $Descripci_on){
            $this->Descipci_on = $Descipci_on;
            $this->Acotaci_on = $Acotaci_on;
            $this->Origen = $Origen;
            $this->Nombre = $Nombre;
            $this->Descripci_on = $Descripci_on;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setDescipci_on(string $Descipci_on): void{
            $this->Descipci_on = $Descipci_on;
        }
        
        public function getDescipci_on(): string{
            return $this->Descipci_on;
        }
        
        public function setAcotaci_on(int $Acotaci_on): void{
            $this->Acotaci_on = $Acotaci_on;
        }
        
        public function getAcotaci_on(): int{
            return $this->Acotaci_on;
        }
        
        public function setOrigen(string $Origen): void{
            $this->Origen = $Origen;
        }
        
        public function getOrigen(): string{
            return $this->Origen;
        }
        
        public function setNombre(?string $Nombre): void{
            $this->Nombre = $Nombre;
        }
        
        public function getNombre(): ?string{
            return $this->Nombre;
        }
        
        public function setDescripci_on(?string $Descripci_on): void{
            $this->Descripci_on = $Descripci_on;
        }
        
        public function getDescripci_on(): ?string{
            return $this->Descripci_on;
        }
        
    }