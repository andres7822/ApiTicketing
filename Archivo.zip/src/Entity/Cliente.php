<?php

    namespace App\Entity;

    class Cliente{
        private int $id;
        private string $Nombre;
        private string $NoCliente;
        private int $Empresa;
        private \DateTime $FechaTupla;
        private int $UsuarioRegistr_o;
        private int $Status;
        private ?int $PaginaWeb;
        private ?float $L_imiteDeCr_edito;

        public function __construct(string $Nombre, string $NoCliente, int $Empresa, \DateTime $FechaTupla, int $UsuarioRegistr_o, int $Status, ?int $PaginaWeb, ?float $L_imiteDeCr_edito){
            $this->Nombre = $Nombre;
            $this->NoCliente = $NoCliente;
            $this->Empresa = $Empresa;
            $this->FechaTupla = $FechaTupla;
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
            $this->Status = $Status;
            $this->PaginaWeb = $PaginaWeb;
            $this->L_imiteDeCr_edito = $L_imiteDeCr_edito;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setNombre(string $Nombre): void{
            $this->Nombre = $Nombre;
        }
        
        public function getNombre(): string{
            return $this->Nombre;
        }
        
        public function setNoCliente(string $NoCliente): void{
            $this->NoCliente = $NoCliente;
        }
        
        public function getNoCliente(): string{
            return $this->NoCliente;
        }
        
        public function setEmpresa(int $Empresa): void{
            $this->Empresa = $Empresa;
        }
        
        public function getEmpresa(): int{
            return $this->Empresa;
        }
        
        public function setFechaTupla(\DateTime $FechaTupla): void{
            $this->FechaTupla = $FechaTupla;
        }
        
        public function getFechaTupla(): \DateTime{
            return $this->FechaTupla;
        }
        
        public function setUsuarioRegistr_o(int $UsuarioRegistr_o): void{
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
        }
        
        public function getUsuarioRegistr_o(): int{
            return $this->UsuarioRegistr_o;
        }
        
        public function setStatus(int $Status): void{
            $this->Status = $Status;
        }
        
        public function getStatus(): int{
            return $this->Status;
        }
        
        public function setPaginaWeb(?int $PaginaWeb): void{
            $this->PaginaWeb = $PaginaWeb;
        }
        
        public function getPaginaWeb(): ?int{
            return $this->PaginaWeb;
        }
        
        public function setL_imiteDeCr_edito(?float $L_imiteDeCr_edito): void{
            $this->L_imiteDeCr_edito = $L_imiteDeCr_edito;
        }
        
        public function getL_imiteDeCr_edito(): ?float{
            return $this->L_imiteDeCr_edito;
        }
        
    }