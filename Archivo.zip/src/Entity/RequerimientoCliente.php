<?php

    namespace App\Entity;

    class RequerimientoCliente{
        private int $id;
        private int $Cliente;
        private \DateTime $Fecha;
        private ?int $Status;
        private string $Valor;
        private int $Solicitante;
        private ?int $Requerimiento;
        private int $UsuarioRegistr_o;
        private int $EmpleadoElabor_o;

        public function __construct(int $Cliente, \DateTime $Fecha, ?int $Status, string $Valor, int $Solicitante, ?int $Requerimiento, int $UsuarioRegistr_o, int $EmpleadoElabor_o){
            $this->Cliente = $Cliente;
            $this->Fecha = $Fecha;
            $this->Status = $Status;
            $this->Valor = $Valor;
            $this->Solicitante = $Solicitante;
            $this->Requerimiento = $Requerimiento;
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
            $this->EmpleadoElabor_o = $EmpleadoElabor_o;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setCliente(int $Cliente): void{
            $this->Cliente = $Cliente;
        }
        
        public function getCliente(): int{
            return $this->Cliente;
        }
        
        public function setFecha(\DateTime $Fecha): void{
            $this->Fecha = $Fecha;
        }
        
        public function getFecha(): \DateTime{
            return $this->Fecha;
        }
        
        public function setStatus(?int $Status): void{
            $this->Status = $Status;
        }
        
        public function getStatus(): ?int{
            return $this->Status;
        }
        
        public function setValor(string $Valor): void{
            $this->Valor = $Valor;
        }
        
        public function getValor(): string{
            return $this->Valor;
        }
        
        public function setSolicitante(int $Solicitante): void{
            $this->Solicitante = $Solicitante;
        }
        
        public function getSolicitante(): int{
            return $this->Solicitante;
        }
        
        public function setRequerimiento(?int $Requerimiento): void{
            $this->Requerimiento = $Requerimiento;
        }
        
        public function getRequerimiento(): ?int{
            return $this->Requerimiento;
        }
        
        public function setUsuarioRegistr_o(int $UsuarioRegistr_o): void{
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
        }
        
        public function getUsuarioRegistr_o(): int{
            return $this->UsuarioRegistr_o;
        }
        
        public function setEmpleadoElabor_o(int $EmpleadoElabor_o): void{
            $this->EmpleadoElabor_o = $EmpleadoElabor_o;
        }
        
        public function getEmpleadoElabor_o(): int{
            return $this->EmpleadoElabor_o;
        }
        
    }