<?php

    namespace App\Entity;

    class Cat_alogoCondicionesComerciales{
        private int $id;
        private string $Nombre;
        private string $Descripci_onCondici_on;
        private int $Requerida;

        public function __construct(string $Nombre, string $Descripci_onCondici_on, int $Requerida){
            $this->Nombre = $Nombre;
            $this->Descripci_onCondici_on = $Descripci_onCondici_on;
            $this->Requerida = $Requerida;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setNombre(string $Nombre): void{
            $this->Nombre = $Nombre;
        }
        
        public function getNombre(): string{
            return $this->Nombre;
        }
        
        public function setDescripci_onCondici_on(string $Descripci_onCondici_on): void{
            $this->Descripci_onCondici_on = $Descripci_onCondici_on;
        }
        
        public function getDescripci_onCondici_on(): string{
            return $this->Descripci_onCondici_on;
        }
        
        public function setRequerida(int $Requerida): void{
            $this->Requerida = $Requerida;
        }
        
        public function getRequerida(): int{
            return $this->Requerida;
        }
        
    }