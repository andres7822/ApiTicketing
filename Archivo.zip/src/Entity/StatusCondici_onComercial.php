<?php

    namespace App\Entity;

    class StatusCondici_onComercial{
        private int $id;
        private string $Nombre;
        private ?string $Descripci_on;

        public function __construct(string $Nombre, ?string $Descripci_on){
            $this->Nombre = $Nombre;
            $this->Descripci_on = $Descripci_on;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setNombre(string $Nombre): void{
            $this->Nombre = $Nombre;
        }
        
        public function getNombre(): string{
            return $this->Nombre;
        }
        
        public function setDescripci_on(?string $Descripci_on): void{
            $this->Descripci_on = $Descripci_on;
        }
        
        public function getDescripci_on(): ?string{
            return $this->Descripci_on;
        }
        
    }