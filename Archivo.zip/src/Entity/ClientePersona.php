<?php

    namespace App\Entity;

    class ClientePersona{
        private int $id;
        private int $Cliente;
        private int $Persona;
        private int $Relaci_on;
        private ?string $Titulo;
        private ?string $Tel_efono;
        private ?string $Tel_efono2;
        private ?string $CorreoElectr_onico;

        public function __construct(int $Cliente, int $Persona, int $Relaci_on, ?string $Titulo, ?string $Tel_efono, ?string $Tel_efono2, ?string $CorreoElectr_onico){
            $this->Cliente = $Cliente;
            $this->Persona = $Persona;
            $this->Relaci_on = $Relaci_on;
            $this->Titulo = $Titulo;
            $this->Tel_efono = $Tel_efono;
            $this->Tel_efono2 = $Tel_efono2;
            $this->CorreoElectr_onico = $CorreoElectr_onico;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setCliente(int $Cliente): void{
            $this->Cliente = $Cliente;
        }
        
        public function getCliente(): int{
            return $this->Cliente;
        }
        
        public function setPersona(int $Persona): void{
            $this->Persona = $Persona;
        }
        
        public function getPersona(): int{
            return $this->Persona;
        }
        
        public function setRelaci_on(int $Relaci_on): void{
            $this->Relaci_on = $Relaci_on;
        }
        
        public function getRelaci_on(): int{
            return $this->Relaci_on;
        }
        
        public function setTitulo(?string $Titulo): void{
            $this->Titulo = $Titulo;
        }
        
        public function getTitulo(): ?string{
            return $this->Titulo;
        }
        
        public function setTel_efono(?string $Tel_efono): void{
            $this->Tel_efono = $Tel_efono;
        }
        
        public function getTel_efono(): ?string{
            return $this->Tel_efono;
        }
        
        public function setTel_efono2(?string $Tel_efono2): void{
            $this->Tel_efono2 = $Tel_efono2;
        }
        
        public function getTel_efono2(): ?string{
            return $this->Tel_efono2;
        }
        
        public function setCorreoElectr_onico(?string $CorreoElectr_onico): void{
            $this->CorreoElectr_onico = $CorreoElectr_onico;
        }
        
        public function getCorreoElectr_onico(): ?string{
            return $this->CorreoElectr_onico;
        }
        
    }