<?php

    namespace App\Entity;

    class Seguimiento{
        private int $id;
        private \DateTime $FechaYHora;
        private string $Descripci_on;
        private string $Conclusiones;
        private int $Status;
        private int $Empleado;
        private int $Medio;
        private int $Prospectaci_on;

        public function __construct(\DateTime $FechaYHora, string $Descripci_on, string $Conclusiones, int $Status, int $Empleado, int $Medio, int $Prospectaci_on){
            $this->FechaYHora = $FechaYHora;
            $this->Descripci_on = $Descripci_on;
            $this->Conclusiones = $Conclusiones;
            $this->Status = $Status;
            $this->Empleado = $Empleado;
            $this->Medio = $Medio;
            $this->Prospectaci_on = $Prospectaci_on;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setFechaYHora(\DateTime $FechaYHora): void{
            $this->FechaYHora = $FechaYHora;
        }
        
        public function getFechaYHora(): \DateTime{
            return $this->FechaYHora;
        }
        
        public function setDescripci_on(string $Descripci_on): void{
            $this->Descripci_on = $Descripci_on;
        }
        
        public function getDescripci_on(): string{
            return $this->Descripci_on;
        }
        
        public function setConclusiones(string $Conclusiones): void{
            $this->Conclusiones = $Conclusiones;
        }
        
        public function getConclusiones(): string{
            return $this->Conclusiones;
        }
        
        public function setStatus(int $Status): void{
            $this->Status = $Status;
        }
        
        public function getStatus(): int{
            return $this->Status;
        }
        
        public function setEmpleado(int $Empleado): void{
            $this->Empleado = $Empleado;
        }
        
        public function getEmpleado(): int{
            return $this->Empleado;
        }
        
        public function setMedio(int $Medio): void{
            $this->Medio = $Medio;
        }
        
        public function getMedio(): int{
            return $this->Medio;
        }
        
        public function setProspectaci_on(int $Prospectaci_on): void{
            $this->Prospectaci_on = $Prospectaci_on;
        }
        
        public function getProspectaci_on(): int{
            return $this->Prospectaci_on;
        }
        
    }