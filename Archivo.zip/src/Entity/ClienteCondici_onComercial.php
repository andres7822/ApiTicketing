<?php

    namespace App\Entity;

    class ClienteCondici_onComercial{
        private int $id;
        private int $Cliente;
        private int $Cat_alogoCondicionesComerciales;
        private string $Descripci_on;
        private ?\DateTime $FechaAceptaci_on;
        private int $Status;
        private int $UsuarioRegistr_o;
        private \DateTime $FechaTupla;

        public function __construct(int $Cliente, int $Cat_alogoCondicionesComerciales, string $Descripci_on, ?\DateTime $FechaAceptaci_on, int $Status, int $UsuarioRegistr_o, \DateTime $FechaTupla){
            $this->Cliente = $Cliente;
            $this->Cat_alogoCondicionesComerciales = $Cat_alogoCondicionesComerciales;
            $this->Descripci_on = $Descripci_on;
            $this->FechaAceptaci_on = $FechaAceptaci_on;
            $this->Status = $Status;
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
            $this->FechaTupla = $FechaTupla;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setCliente(int $Cliente): void{
            $this->Cliente = $Cliente;
        }
        
        public function getCliente(): int{
            return $this->Cliente;
        }
        
        public function setCat_alogoCondicionesComerciales(int $Cat_alogoCondicionesComerciales): void{
            $this->Cat_alogoCondicionesComerciales = $Cat_alogoCondicionesComerciales;
        }
        
        public function getCat_alogoCondicionesComerciales(): int{
            return $this->Cat_alogoCondicionesComerciales;
        }
        
        public function setDescripci_on(string $Descripci_on): void{
            $this->Descripci_on = $Descripci_on;
        }
        
        public function getDescripci_on(): string{
            return $this->Descripci_on;
        }
        
        public function setFechaAceptaci_on(?\DateTime $FechaAceptaci_on): void{
            $this->FechaAceptaci_on = $FechaAceptaci_on;
        }
        
        public function getFechaAceptaci_on(): ?\DateTime{
            return $this->FechaAceptaci_on;
        }
        
        public function setStatus(int $Status): void{
            $this->Status = $Status;
        }
        
        public function getStatus(): int{
            return $this->Status;
        }
        
        public function setUsuarioRegistr_o(int $UsuarioRegistr_o): void{
            $this->UsuarioRegistr_o = $UsuarioRegistr_o;
        }
        
        public function getUsuarioRegistr_o(): int{
            return $this->UsuarioRegistr_o;
        }
        
        public function setFechaTupla(\DateTime $FechaTupla): void{
            $this->FechaTupla = $FechaTupla;
        }
        
        public function getFechaTupla(): \DateTime{
            return $this->FechaTupla;
        }
        
    }