<?php

    namespace App\Entity;

    class Persona{
        private int $id;
        private string $NombreORaz_onSocial;
        private string $Tel_efono;
        private string $CorreoElectr_onico;
        private int $TipoDePersona;
        private ?int $DatosFiscales;

        public function __construct(string $NombreORaz_onSocial, string $Tel_efono, string $CorreoElectr_onico, int $TipoDePersona, ?int $DatosFiscales){
            $this->NombreORaz_onSocial = $NombreORaz_onSocial;
            $this->Tel_efono = $Tel_efono;
            $this->CorreoElectr_onico = $CorreoElectr_onico;
            $this->TipoDePersona = $TipoDePersona;
            $this->DatosFiscales = $DatosFiscales;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setNombreORaz_onSocial(string $NombreORaz_onSocial): void{
            $this->NombreORaz_onSocial = $NombreORaz_onSocial;
        }
        
        public function getNombreORaz_onSocial(): string{
            return $this->NombreORaz_onSocial;
        }
        
        public function setTel_efono(string $Tel_efono): void{
            $this->Tel_efono = $Tel_efono;
        }
        
        public function getTel_efono(): string{
            return $this->Tel_efono;
        }
        
        public function setCorreoElectr_onico(string $CorreoElectr_onico): void{
            $this->CorreoElectr_onico = $CorreoElectr_onico;
        }
        
        public function getCorreoElectr_onico(): string{
            return $this->CorreoElectr_onico;
        }
        
        public function setTipoDePersona(int $TipoDePersona): void{
            $this->TipoDePersona = $TipoDePersona;
        }
        
        public function getTipoDePersona(): int{
            return $this->TipoDePersona;
        }
        
        public function setDatosFiscales(?int $DatosFiscales): void{
            $this->DatosFiscales = $DatosFiscales;
        }
        
        public function getDatosFiscales(): ?int{
            return $this->DatosFiscales;
        }
        
    }