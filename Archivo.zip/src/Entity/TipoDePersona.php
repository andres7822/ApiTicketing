<?php

    namespace App\Entity;

    class TipoDePersona{
        private int $id;
        private string $Descripci_on;

        public function __construct(string $Descripci_on){
            $this->Descripci_on = $Descripci_on;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setDescripci_on(string $Descripci_on): void{
            $this->Descripci_on = $Descripci_on;
        }
        
        public function getDescripci_on(): string{
            return $this->Descripci_on;
        }
        
    }