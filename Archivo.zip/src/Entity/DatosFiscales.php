<?php

    namespace App\Entity;

    class DatosFiscales{
        private int $id;
        private string $NombreORaz_onSocial;
        private string $RFC;
        private int $R_egimenFiscal;
        private int $Domicilio;
        private \DateTime $FechaTupla;
        private string $Origen;
        private string $Tupla;

        public function __construct(string $NombreORaz_onSocial, string $RFC, int $R_egimenFiscal, int $Domicilio, \DateTime $FechaTupla, string $Origen, string $Tupla){
            $this->NombreORaz_onSocial = $NombreORaz_onSocial;
            $this->RFC = $RFC;
            $this->R_egimenFiscal = $R_egimenFiscal;
            $this->Domicilio = $Domicilio;
            $this->FechaTupla = $FechaTupla;
            $this->Origen = $Origen;
            $this->Tupla = $Tupla;
        }
        
        public function setId(int $id): void{
            $this->id = $id;
        }
        
        public function getId(): int{
            return $this->id;
        }
        
        public function setNombreORaz_onSocial(string $NombreORaz_onSocial): void{
            $this->NombreORaz_onSocial = $NombreORaz_onSocial;
        }
        
        public function getNombreORaz_onSocial(): string{
            return $this->NombreORaz_onSocial;
        }
        
        public function setRFC(string $RFC): void{
            $this->RFC = $RFC;
        }
        
        public function getRFC(): string{
            return $this->RFC;
        }
        
        public function setR_egimenFiscal(int $R_egimenFiscal): void{
            $this->R_egimenFiscal = $R_egimenFiscal;
        }
        
        public function getR_egimenFiscal(): int{
            return $this->R_egimenFiscal;
        }
        
        public function setDomicilio(int $Domicilio): void{
            $this->Domicilio = $Domicilio;
        }
        
        public function getDomicilio(): int{
            return $this->Domicilio;
        }
        
        public function setFechaTupla(\DateTime $FechaTupla): void{
            $this->FechaTupla = $FechaTupla;
        }
        
        public function getFechaTupla(): \DateTime{
            return $this->FechaTupla;
        }
        
        public function setOrigen(string $Origen): void{
            $this->Origen = $Origen;
        }
        
        public function getOrigen(): string{
            return $this->Origen;
        }
        
        public function setTupla(string $Tupla): void{
            $this->Tupla = $Tupla;
        }
        
        public function getTupla(): string{
            return $this->Tupla;
        }
        
    }