<?php

    namespace App\Service\Persona;

    use App\Entity\Persona;
    use App\Repository\PersonaRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class PersonaRegisterService{
        private PersonaRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(PersonaRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(string $NombreORaz_onSocial, string $Tel_efono, string $CorreoElectr_onico, int $TipoDePersona, ?int $DatosFiscales): Persona{
            $Persona = new Persona($NombreORaz_onSocial, $Tel_efono, $CorreoElectr_onico, $TipoDePersona, $DatosFiscales);

            $this->repository->save($Persona);

            $data = [
                'NombreORaz_onSocial' => $Persona->getNombreORaz_onSocial(),
                'Tel_efono' => $Persona->getTel_efono(),
                'CorreoElectr_onico' => $Persona->getCorreoElectr_onico(),
                'TipoDePersona' => $Persona->getTipoDePersona(),
                'DatosFiscales' => $Persona->getDatosFiscales()
            ];
            $this->accesoService->create('Persona', $Persona->getId(), 2, $data);

            return $Persona;
        }
    }