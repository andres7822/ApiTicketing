<?php

    namespace App\Service\Persona;

    use App\Entity\Persona;
    use App\Repository\PersonaRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class PersonaUpdateService{
        private PersonaRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(PersonaRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, string $NombreORaz_onSocial, string $Tel_efono, string $CorreoElectr_onico, int $TipoDePersona, ?int $DatosFiscales): Persona{
            $Persona = $this->repository->findById($id);
            $Persona->setNombreORaz_onSocial($NombreORaz_onSocial);
            $Persona->setTel_efono($Tel_efono);
            $Persona->setCorreoElectr_onico($CorreoElectr_onico);
            $Persona->setTipoDePersona($TipoDePersona);
            $Persona->setDatosFiscales($DatosFiscales);
            $this->repository->save($Persona);

            $data = [
                'NombreORaz_onSocial' => $Persona->getNombreORaz_onSocial(),
                'Tel_efono' => $Persona->getTel_efono(),
                'CorreoElectr_onico' => $Persona->getCorreoElectr_onico(),
                'TipoDePersona' => $Persona->getTipoDePersona(),
                'DatosFiscales' => $Persona->getDatosFiscales()
            ];
            $this->accesoService->create('Persona', $id, 5, $data);

            return $Persona;
        }
    }