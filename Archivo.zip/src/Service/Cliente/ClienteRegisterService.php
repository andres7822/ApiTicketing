<?php

    namespace App\Service\Cliente;

    use App\Entity\Cliente;
    use App\Repository\ClienteRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClienteRegisterService{
        private ClienteRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClienteRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(string $Nombre, string $NoCliente, int $Empresa, \DateTime $FechaTupla, int $UsuarioRegistr_o, int $Status, ?int $PaginaWeb, ?float $L_imiteDeCr_edito): Cliente{
            $Cliente = new Cliente($Nombre, $NoCliente, $Empresa, $FechaTupla, $UsuarioRegistr_o, $Status, $PaginaWeb, $L_imiteDeCr_edito);

            $this->repository->save($Cliente);

            $data = [
                'Nombre' => $Cliente->getNombre(),
                'NoCliente' => $Cliente->getNoCliente(),
                'Empresa' => $Cliente->getEmpresa(),
                'FechaTupla' => $Cliente->getFechaTupla(),
                'UsuarioRegistr_o' => $Cliente->getUsuarioRegistr_o(),
                'Status' => $Cliente->getStatus(),
                'PaginaWeb' => $Cliente->getPaginaWeb(),
                'L_imiteDeCr_edito' => $Cliente->getL_imiteDeCr_edito()
            ];
            $this->accesoService->create('Cliente', $Cliente->getId(), 2, $data);

            return $Cliente;
        }
    }