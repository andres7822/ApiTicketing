<?php

    namespace App\Service\Prospectaci_on;

    use App\Entity\Prospectaci_on;
    use App\Repository\Prospectaci_onRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Prospectaci_onDataService{
        private Prospectaci_onRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Prospectaci_onRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function data(int $id): Prospectaci_on{
            $Prospectaci_on = $this->repository->findById($id);
            $data = [
                'Cliente' => $Prospectaci_on->getCliente(),
                'FechaYHora' => $Prospectaci_on->getFechaYHora(),
                'TipoDeServicio' => $Prospectaci_on->getTipoDeServicio(),
                'Descripci_onDelServicio' => $Prospectaci_on->getDescripci_onDelServicio(),
                'Usuario' => $Prospectaci_on->getUsuario(),
                'Empleado' => $Prospectaci_on->getEmpleado(),
                'Status' => $Prospectaci_on->getStatus(),
                'Canalizado' => $Prospectaci_on->getCanalizado()
            ];

            $this->accesoService->create('Prospectaci_on', $id, 4, $data);

            return $Prospectaci_on;
        }
    }