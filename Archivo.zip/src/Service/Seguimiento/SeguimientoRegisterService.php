<?php

    namespace App\Service\Seguimiento;

    use App\Entity\Seguimiento;
    use App\Repository\SeguimientoRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class SeguimientoRegisterService{
        private SeguimientoRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(SeguimientoRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(\DateTime $FechaYHora, string $Descripci_on, string $Conclusiones, int $Status, int $Empleado, int $Medio, int $Prospectaci_on): Seguimiento{
            $Seguimiento = new Seguimiento($FechaYHora, $Descripci_on, $Conclusiones, $Status, $Empleado, $Medio, $Prospectaci_on);

            $this->repository->save($Seguimiento);

            $data = [
                'FechaYHora' => $Seguimiento->getFechaYHora(),
                'Descripci_on' => $Seguimiento->getDescripci_on(),
                'Conclusiones' => $Seguimiento->getConclusiones(),
                'Status' => $Seguimiento->getStatus(),
                'Empleado' => $Seguimiento->getEmpleado(),
                'Medio' => $Seguimiento->getMedio(),
                'Prospectaci_on' => $Seguimiento->getProspectaci_on()
            ];
            $this->accesoService->create('Seguimiento', $Seguimiento->getId(), 2, $data);

            return $Seguimiento;
        }
    }