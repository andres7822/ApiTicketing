<?php

    namespace App\Service\Seguimiento;

    use App\Entity\Seguimiento;
    use App\Repository\SeguimientoRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class SeguimientoUpdateService{
        private SeguimientoRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(SeguimientoRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, \DateTime $FechaYHora, string $Descripci_on, string $Conclusiones, int $Status, int $Empleado, int $Medio, int $Prospectaci_on): Seguimiento{
            $Seguimiento = $this->repository->findById($id);
            $Seguimiento->setFechaYHora($FechaYHora);
            $Seguimiento->setDescripci_on($Descripci_on);
            $Seguimiento->setConclusiones($Conclusiones);
            $Seguimiento->setStatus($Status);
            $Seguimiento->setEmpleado($Empleado);
            $Seguimiento->setMedio($Medio);
            $Seguimiento->setProspectaci_on($Prospectaci_on);
            $this->repository->save($Seguimiento);

            $data = [
                'FechaYHora' => $Seguimiento->getFechaYHora(),
                'Descripci_on' => $Seguimiento->getDescripci_on(),
                'Conclusiones' => $Seguimiento->getConclusiones(),
                'Status' => $Seguimiento->getStatus(),
                'Empleado' => $Seguimiento->getEmpleado(),
                'Medio' => $Seguimiento->getMedio(),
                'Prospectaci_on' => $Seguimiento->getProspectaci_on()
            ];
            $this->accesoService->create('Seguimiento', $id, 5, $data);

            return $Seguimiento;
        }
    }