<?php

    namespace App\Service\ClienteCondici_onComercial;

    use App\Entity\ClienteCondici_onComercial;
    use App\Repository\ClienteCondici_onComercialRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClienteCondici_onComercialDataService{
        private ClienteCondici_onComercialRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClienteCondici_onComercialRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function data(int $id): ClienteCondici_onComercial{
            $ClienteCondici_onComercial = $this->repository->findById($id);
            $data = [
                'Cliente' => $ClienteCondici_onComercial->getCliente(),
                'Cat_alogoCondicionesComerciales' => $ClienteCondici_onComercial->getCat_alogoCondicionesComerciales(),
                'Descripci_on' => $ClienteCondici_onComercial->getDescripci_on(),
                'FechaAceptaci_on' => $ClienteCondici_onComercial->getFechaAceptaci_on(),
                'Status' => $ClienteCondici_onComercial->getStatus(),
                'UsuarioRegistr_o' => $ClienteCondici_onComercial->getUsuarioRegistr_o(),
                'FechaTupla' => $ClienteCondici_onComercial->getFechaTupla()
            ];

            $this->accesoService->create('ClienteCondici_onComercial', $id, 4, $data);

            return $ClienteCondici_onComercial;
        }
    }