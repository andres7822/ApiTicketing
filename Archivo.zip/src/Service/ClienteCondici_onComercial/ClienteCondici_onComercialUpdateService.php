<?php

    namespace App\Service\ClienteCondici_onComercial;

    use App\Entity\ClienteCondici_onComercial;
    use App\Repository\ClienteCondici_onComercialRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClienteCondici_onComercialUpdateService{
        private ClienteCondici_onComercialRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClienteCondici_onComercialRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, int $Cliente, int $Cat_alogoCondicionesComerciales, string $Descripci_on, ?\DateTime $FechaAceptaci_on, int $Status, int $UsuarioRegistr_o, \DateTime $FechaTupla): ClienteCondici_onComercial{
            $ClienteCondici_onComercial = $this->repository->findById($id);
            $ClienteCondici_onComercial->setCliente($Cliente);
            $ClienteCondici_onComercial->setCat_alogoCondicionesComerciales($Cat_alogoCondicionesComerciales);
            $ClienteCondici_onComercial->setDescripci_on($Descripci_on);
            $ClienteCondici_onComercial->setFechaAceptaci_on($FechaAceptaci_on);
            $ClienteCondici_onComercial->setStatus($Status);
            $ClienteCondici_onComercial->setUsuarioRegistr_o($UsuarioRegistr_o);
            $ClienteCondici_onComercial->setFechaTupla($FechaTupla);
            $this->repository->save($ClienteCondici_onComercial);

            $data = [
                'Cliente' => $ClienteCondici_onComercial->getCliente(),
                'Cat_alogoCondicionesComerciales' => $ClienteCondici_onComercial->getCat_alogoCondicionesComerciales(),
                'Descripci_on' => $ClienteCondici_onComercial->getDescripci_on(),
                'FechaAceptaci_on' => $ClienteCondici_onComercial->getFechaAceptaci_on(),
                'Status' => $ClienteCondici_onComercial->getStatus(),
                'UsuarioRegistr_o' => $ClienteCondici_onComercial->getUsuarioRegistr_o(),
                'FechaTupla' => $ClienteCondici_onComercial->getFechaTupla()
            ];
            $this->accesoService->create('ClienteCondici_onComercial', $id, 5, $data);

            return $ClienteCondici_onComercial;
        }
    }