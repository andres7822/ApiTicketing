<?php

    namespace App\Service\Cat_alogoDeDocumento;

    use App\Entity\Cat_alogoDeDocumento;
    use App\Repository\Cat_alogoDeDocumentoRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Cat_alogoDeDocumentoRegisterService{
        private Cat_alogoDeDocumentoRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Cat_alogoDeDocumentoRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(string $Nombre, ?string $Descripci_on, int $Activo, int $Prioridad, string $Origen, ?int $Requerido): Cat_alogoDeDocumento{
            $Cat_alogoDeDocumento = new Cat_alogoDeDocumento($Nombre, $Descripci_on, $Activo, $Prioridad, $Origen, $Requerido);

            $this->repository->save($Cat_alogoDeDocumento);

            $data = [
                'Nombre' => $Cat_alogoDeDocumento->getNombre(),
                'Descripci_on' => $Cat_alogoDeDocumento->getDescripci_on(),
                'Activo' => $Cat_alogoDeDocumento->getActivo(),
                'Prioridad' => $Cat_alogoDeDocumento->getPrioridad(),
                'Origen' => $Cat_alogoDeDocumento->getOrigen(),
                'Requerido' => $Cat_alogoDeDocumento->getRequerido()
            ];
            $this->accesoService->create('Cat_alogoDeDocumento', $Cat_alogoDeDocumento->getId(), 2, $data);

            return $Cat_alogoDeDocumento;
        }
    }