<?php

    namespace App\Service\Cat_alogoDeDocumento;

    use App\Entity\Cat_alogoDeDocumento;
    use App\Repository\Cat_alogoDeDocumentoRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Cat_alogoDeDocumentoUpdateService{
        private Cat_alogoDeDocumentoRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Cat_alogoDeDocumentoRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, string $Nombre, ?string $Descripci_on, int $Activo, int $Prioridad, string $Origen, ?int $Requerido): Cat_alogoDeDocumento{
            $Cat_alogoDeDocumento = $this->repository->findById($id);
            $Cat_alogoDeDocumento->setNombre($Nombre);
            $Cat_alogoDeDocumento->setDescripci_on($Descripci_on);
            $Cat_alogoDeDocumento->setActivo($Activo);
            $Cat_alogoDeDocumento->setPrioridad($Prioridad);
            $Cat_alogoDeDocumento->setOrigen($Origen);
            $Cat_alogoDeDocumento->setRequerido($Requerido);
            $this->repository->save($Cat_alogoDeDocumento);

            $data = [
                'Nombre' => $Cat_alogoDeDocumento->getNombre(),
                'Descripci_on' => $Cat_alogoDeDocumento->getDescripci_on(),
                'Activo' => $Cat_alogoDeDocumento->getActivo(),
                'Prioridad' => $Cat_alogoDeDocumento->getPrioridad(),
                'Origen' => $Cat_alogoDeDocumento->getOrigen(),
                'Requerido' => $Cat_alogoDeDocumento->getRequerido()
            ];
            $this->accesoService->create('Cat_alogoDeDocumento', $id, 5, $data);

            return $Cat_alogoDeDocumento;
        }
    }