<?php

    namespace App\Service\Cat_alogoDeDocumento;

    use App\Entity\Cat_alogoDeDocumento;
    use App\Repository\Cat_alogoDeDocumentoRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Cat_alogoDeDocumentoDeleteService{
        private Cat_alogoDeDocumentoRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Cat_alogoDeDocumentoRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function delete(int $id): Cat_alogoDeDocumento{
            $Cat_alogoDeDocumento = $this->repository->findById($id);
            $data = [
                'Nombre' => $Cat_alogoDeDocumento->getNombre(),
                'Descripci_on' => $Cat_alogoDeDocumento->getDescripci_on(),
                'Activo' => $Cat_alogoDeDocumento->getActivo(),
                'Prioridad' => $Cat_alogoDeDocumento->getPrioridad(),
                'Origen' => $Cat_alogoDeDocumento->getOrigen(),
                'Requerido' => $Cat_alogoDeDocumento->getRequerido()
            ];

            $this->repository->removeEntity($Cat_alogoDeDocumento);

            $this->accesoService->create('Cat_alogoDeDocumento', $id, 3, $data);

            return $Cat_alogoDeDocumento;
        }
    }