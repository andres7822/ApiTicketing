<?php

    namespace App\Service\StatusProspectaci_on;

    use App\Entity\StatusProspectaci_on;
    use App\Repository\StatusProspectaci_onRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class StatusProspectaci_onUpdateService{
        private StatusProspectaci_onRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(StatusProspectaci_onRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, string $Descipci_on, string $Acotaci_on, string $Origen, ?string $Nombre, ?string $Descripci_on): StatusProspectaci_on{
            $StatusProspectaci_on = $this->repository->findById($id);
            $StatusProspectaci_on->setDescipci_on($Descipci_on);
            $StatusProspectaci_on->setAcotaci_on($Acotaci_on);
            $StatusProspectaci_on->setOrigen($Origen);
            $StatusProspectaci_on->setNombre($Nombre);
            $StatusProspectaci_on->setDescripci_on($Descripci_on);
            $this->repository->save($StatusProspectaci_on);

            $data = [
                'Descipci_on' => $StatusProspectaci_on->getDescipci_on(),
                'Acotaci_on' => $StatusProspectaci_on->getAcotaci_on(),
                'Origen' => $StatusProspectaci_on->getOrigen(),
                'Nombre' => $StatusProspectaci_on->getNombre(),
                'Descripci_on' => $StatusProspectaci_on->getDescripci_on()
            ];
            $this->accesoService->create('StatusProspectaci_on', $id, 5, $data);

            return $StatusProspectaci_on;
        }
    }