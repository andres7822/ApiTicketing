<?php

    namespace App\Service\StatusProspectaci_on;

    use App\Entity\StatusProspectaci_on;
    use App\Repository\StatusProspectaci_onRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class StatusProspectaci_onDataService{
        private StatusProspectaci_onRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(StatusProspectaci_onRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function data(int $id): StatusProspectaci_on{
            $StatusProspectaci_on = $this->repository->findById($id);
            $data = [
                'Descipci_on' => $StatusProspectaci_on->getDescipci_on(),
                'Acotaci_on' => $StatusProspectaci_on->getAcotaci_on(),
                'Origen' => $StatusProspectaci_on->getOrigen(),
                'Nombre' => $StatusProspectaci_on->getNombre(),
                'Descripci_on' => $StatusProspectaci_on->getDescripci_on()
            ];

            $this->accesoService->create('StatusProspectaci_on', $id, 4, $data);

            return $StatusProspectaci_on;
        }
    }