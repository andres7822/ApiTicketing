<?php

    namespace App\Service\Cat_alogoDeRequerimientos;

    use App\Entity\Cat_alogoDeRequerimientos;
    use App\Repository\Cat_alogoDeRequerimientosRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Cat_alogoDeRequerimientosDataService{
        private Cat_alogoDeRequerimientosRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Cat_alogoDeRequerimientosRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function data(int $id): Cat_alogoDeRequerimientos{
            $Cat_alogoDeRequerimientos = $this->repository->findById($id);
            $data = [
                'TipoDeServicio' => $Cat_alogoDeRequerimientos->getTipoDeServicio(),
                'Requerimiento' => $Cat_alogoDeRequerimientos->getRequerimiento(),
                'Orden' => $Cat_alogoDeRequerimientos->getOrden(),
                'Requerido' => $Cat_alogoDeRequerimientos->getRequerido(),
                'Cat_alogo' => $Cat_alogoDeRequerimientos->getCat_alogo()
            ];

            $this->accesoService->create('Cat_alogoDeRequerimientos', $id, 4, $data);

            return $Cat_alogoDeRequerimientos;
        }
    }