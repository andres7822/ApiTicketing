<?php

    namespace App\Service\Domicilio;

    use App\Entity\Domicilio;
    use App\Repository\DomicilioRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class DomicilioUpdateService{
        private DomicilioRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(DomicilioRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, ?int $TipoDeVialidad, ?string $Vialidad, ?int $TipoDeAsentamiento, ?string $Asentamiento, ?string $N_umeroExterior, ?string $N_umeroInterior, ?string $Pa_is, ?string $EntidadFederativa, ?string $Municipio, ?string $Localidad, ?string $C_odigoPostal, ?string $Latitud, ?string $Longitud, ?string $GooglePin, int $Visible, int $Actual, \DateTime $FechaTupla, string $Origen, string $Tupla): Domicilio{
            $Domicilio = $this->repository->findById($id);
            $Domicilio->setTipoDeVialidad($TipoDeVialidad);
            $Domicilio->setVialidad($Vialidad);
            $Domicilio->setTipoDeAsentamiento($TipoDeAsentamiento);
            $Domicilio->setAsentamiento($Asentamiento);
            $Domicilio->setN_umeroExterior($N_umeroExterior);
            $Domicilio->setN_umeroInterior($N_umeroInterior);
            $Domicilio->setPa_is($Pa_is);
            $Domicilio->setEntidadFederativa($EntidadFederativa);
            $Domicilio->setMunicipio($Municipio);
            $Domicilio->setLocalidad($Localidad);
            $Domicilio->setC_odigoPostal($C_odigoPostal);
            $Domicilio->setLatitud($Latitud);
            $Domicilio->setLongitud($Longitud);
            $Domicilio->setGooglePin($GooglePin);
            $Domicilio->setVisible($Visible);
            $Domicilio->setActual($Actual);
            $Domicilio->setFechaTupla($FechaTupla);
            $Domicilio->setOrigen($Origen);
            $Domicilio->setTupla($Tupla);
            $this->repository->save($Domicilio);

            $data = [
                'TipoDeVialidad' => $Domicilio->getTipoDeVialidad(),
                'Vialidad' => $Domicilio->getVialidad(),
                'TipoDeAsentamiento' => $Domicilio->getTipoDeAsentamiento(),
                'Asentamiento' => $Domicilio->getAsentamiento(),
                'N_umeroExterior' => $Domicilio->getN_umeroExterior(),
                'N_umeroInterior' => $Domicilio->getN_umeroInterior(),
                'Pa_is' => $Domicilio->getPa_is(),
                'EntidadFederativa' => $Domicilio->getEntidadFederativa(),
                'Municipio' => $Domicilio->getMunicipio(),
                'Localidad' => $Domicilio->getLocalidad(),
                'C_odigoPostal' => $Domicilio->getC_odigoPostal(),
                'Latitud' => $Domicilio->getLatitud(),
                'Longitud' => $Domicilio->getLongitud(),
                'GooglePin' => $Domicilio->getGooglePin(),
                'Visible' => $Domicilio->getVisible(),
                'Actual' => $Domicilio->getActual(),
                'FechaTupla' => $Domicilio->getFechaTupla(),
                'Origen' => $Domicilio->getOrigen(),
                'Tupla' => $Domicilio->getTupla()
            ];
            $this->accesoService->create('Domicilio', $id, 5, $data);

            return $Domicilio;
        }
    }