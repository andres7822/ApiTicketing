<?php

    namespace App\Service\StatusCondici_onComercial;

    use App\Entity\StatusCondici_onComercial;
    use App\Repository\StatusCondici_onComercialRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class StatusCondici_onComercialRegisterService{
        private StatusCondici_onComercialRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(StatusCondici_onComercialRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(string $Nombre, ?string $Descripci_on): StatusCondici_onComercial{
            $StatusCondici_onComercial = new StatusCondici_onComercial($Nombre, $Descripci_on);

            $this->repository->save($StatusCondici_onComercial);

            $data = [
                'Nombre' => $StatusCondici_onComercial->getNombre(),
                'Descripci_on' => $StatusCondici_onComercial->getDescripci_on()
            ];
            $this->accesoService->create('StatusCondici_onComercial', $StatusCondici_onComercial->getId(), 2, $data);

            return $StatusCondici_onComercial;
        }
    }