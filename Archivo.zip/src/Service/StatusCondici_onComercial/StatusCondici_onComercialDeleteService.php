<?php

    namespace App\Service\StatusCondici_onComercial;

    use App\Entity\StatusCondici_onComercial;
    use App\Repository\StatusCondici_onComercialRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class StatusCondici_onComercialDeleteService{
        private StatusCondici_onComercialRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(StatusCondici_onComercialRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function delete(int $id): StatusCondici_onComercial{
            $StatusCondici_onComercial = $this->repository->findById($id);
            $data = [
                'Nombre' => $StatusCondici_onComercial->getNombre(),
                'Descripci_on' => $StatusCondici_onComercial->getDescripci_on()
            ];

            $this->repository->removeEntity($StatusCondici_onComercial);

            $this->accesoService->create('StatusCondici_onComercial', $id, 3, $data);

            return $StatusCondici_onComercial;
        }
    }