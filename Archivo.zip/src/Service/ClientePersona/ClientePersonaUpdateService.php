<?php

    namespace App\Service\ClientePersona;

    use App\Entity\ClientePersona;
    use App\Repository\ClientePersonaRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClientePersonaUpdateService{
        private ClientePersonaRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClientePersonaRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function update(int $id, int $Cliente, int $Persona, int $Relaci_on, ?string $Titulo, ?string $Tel_efono, ?string $Tel_efono2, ?string $CorreoElectr_onico): ClientePersona{
            $ClientePersona = $this->repository->findById($id);
            $ClientePersona->setCliente($Cliente);
            $ClientePersona->setPersona($Persona);
            $ClientePersona->setRelaci_on($Relaci_on);
            $ClientePersona->setTitulo($Titulo);
            $ClientePersona->setTel_efono($Tel_efono);
            $ClientePersona->setTel_efono2($Tel_efono2);
            $ClientePersona->setCorreoElectr_onico($CorreoElectr_onico);
            $this->repository->save($ClientePersona);

            $data = [
                'Cliente' => $ClientePersona->getCliente(),
                'Persona' => $ClientePersona->getPersona(),
                'Relaci_on' => $ClientePersona->getRelaci_on(),
                'Titulo' => $ClientePersona->getTitulo(),
                'Tel_efono' => $ClientePersona->getTel_efono(),
                'Tel_efono2' => $ClientePersona->getTel_efono2(),
                'CorreoElectr_onico' => $ClientePersona->getCorreoElectr_onico()
            ];
            $this->accesoService->create('ClientePersona', $id, 5, $data);

            return $ClientePersona;
        }
    }