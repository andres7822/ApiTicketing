<?php

    namespace App\Service\ClientePersona;

    use App\Entity\ClientePersona;
    use App\Repository\ClientePersonaRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClientePersonaRegisterService{
        private ClientePersonaRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClientePersonaRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function create(int $Cliente, int $Persona, int $Relaci_on, ?string $Titulo, ?string $Tel_efono, ?string $Tel_efono2, ?string $CorreoElectr_onico): ClientePersona{
            $ClientePersona = new ClientePersona($Cliente, $Persona, $Relaci_on, $Titulo, $Tel_efono, $Tel_efono2, $CorreoElectr_onico);

            $this->repository->save($ClientePersona);

            $data = [
                'Cliente' => $ClientePersona->getCliente(),
                'Persona' => $ClientePersona->getPersona(),
                'Relaci_on' => $ClientePersona->getRelaci_on(),
                'Titulo' => $ClientePersona->getTitulo(),
                'Tel_efono' => $ClientePersona->getTel_efono(),
                'Tel_efono2' => $ClientePersona->getTel_efono2(),
                'CorreoElectr_onico' => $ClientePersona->getCorreoElectr_onico()
            ];
            $this->accesoService->create('ClientePersona', $ClientePersona->getId(), 2, $data);

            return $ClientePersona;
        }
    }