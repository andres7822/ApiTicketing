<?php

    namespace App\Service\ClientePersona;

    use App\Entity\ClientePersona;
    use App\Repository\ClientePersonaRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class ClientePersonaDataService{
        private ClientePersonaRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(ClientePersonaRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function data(int $id): ClientePersona{
            $ClientePersona = $this->repository->findById($id);
            $data = [
                'Cliente' => $ClientePersona->getCliente(),
                'Persona' => $ClientePersona->getPersona(),
                'Relaci_on' => $ClientePersona->getRelaci_on(),
                'Titulo' => $ClientePersona->getTitulo(),
                'Tel_efono' => $ClientePersona->getTel_efono(),
                'Tel_efono2' => $ClientePersona->getTel_efono2(),
                'CorreoElectr_onico' => $ClientePersona->getCorreoElectr_onico()
            ];

            $this->accesoService->create('ClientePersona', $id, 4, $data);

            return $ClientePersona;
        }
    }