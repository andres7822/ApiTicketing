<?php

    namespace App\Service\Cat_alogoCondicionesComerciales;

    use App\Entity\Cat_alogoCondicionesComerciales;
    use App\Repository\Cat_alogoCondicionesComercialesRepository;
    use App\Service\systemLog\systemLogRegisterService;
    use Doctrine\ORM\OptimisticLockException;
    use Doctrine\ORM\ORMException;

    class Cat_alogoCondicionesComercialesDeleteService{
        private Cat_alogoCondicionesComercialesRepository $repository;
        private systemLogRegisterService $accesoService;

        public function __construct(Cat_alogoCondicionesComercialesRepository $repository,
                                    systemLogRegisterService $accesoService){
            $this->repository = $repository;
            $this->accesoService = $accesoService;
        }

        /**
         * @throws OptimisticLockException
         * @throws ORMException
         */
        public function delete(int $id): Cat_alogoCondicionesComerciales{
            $Cat_alogoCondicionesComerciales = $this->repository->findById($id);
            $data = [
                'Nombre' => $Cat_alogoCondicionesComerciales->getNombre(),
                'Descripci_onCondici_on' => $Cat_alogoCondicionesComerciales->getDescripci_onCondici_on(),
                'Requerida' => $Cat_alogoCondicionesComerciales->getRequerida()
            ];

            $this->repository->removeEntity($Cat_alogoCondicionesComerciales);

            $this->accesoService->create('Cat_alogoCondicionesComerciales', $id, 3, $data);

            return $Cat_alogoCondicionesComerciales;
        }
    }